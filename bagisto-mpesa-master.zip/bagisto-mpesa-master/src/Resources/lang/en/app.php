<?php

return [
    'payment' => [
        'description' => 'Pay securely using M-Pesa mobile money',
    ],
];
