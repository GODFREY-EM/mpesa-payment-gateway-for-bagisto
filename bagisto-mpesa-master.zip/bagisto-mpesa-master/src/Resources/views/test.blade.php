<h1>M-Pesa Test View</h1>
<p>This is a test view to check if rendering works correctly.</p>