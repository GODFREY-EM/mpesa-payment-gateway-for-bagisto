@push('scripts')
    @include('mpesa::mpesa-checkout-integration')
@endpush
